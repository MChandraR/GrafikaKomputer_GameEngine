class gameobject{
    constructor(id,name,sizeX,sizeY,x,y){
       this.objects = 
    }

    getgameobject(){
        return this.objects;
    }

}
